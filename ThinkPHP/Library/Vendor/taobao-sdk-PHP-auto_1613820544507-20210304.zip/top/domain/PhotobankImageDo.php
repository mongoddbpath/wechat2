<?php

/**
 * list
 * @author auto create
 */
class PhotobankImageDo
{
	
	/** 
	 * fileName
	 **/
	public $file_name;
	
	/** 
	 * fileSize
	 **/
	public $file_size;
	
	/** 
	 * gmtModified
	 **/
	public $gmt_modified;
	
	/** 
	 * groupId
	 **/
	public $group_id;
	
	/** 
	 * 111111
	 **/
	public $id;
	
	/** 
	 * ownerMemberDisplayName
	 **/
	public $owner_member_display_name;
	
	/** 
	 * referenceCount
	 **/
	public $reference_count;
	
	/** 
	 * full url
	 **/
	public $url;	
}
?>