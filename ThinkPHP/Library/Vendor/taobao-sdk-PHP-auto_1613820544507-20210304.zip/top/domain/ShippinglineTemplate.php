<?php

/**
 * 运费模板
 * @author auto create
 */
class ShippinglineTemplate
{
	
	/** 
	 * 运费模板id
	 **/
	public $id;
	
	/** 
	 * 运费模板名称
	 **/
	public $title;	
}
?>