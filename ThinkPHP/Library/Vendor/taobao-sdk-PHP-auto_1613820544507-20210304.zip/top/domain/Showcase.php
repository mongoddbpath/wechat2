<?php

/**
 * result
 * @author auto create
 */
class Showcase
{
	
	/** 
	 * 橱窗id
	 **/
	public $id;
	
	/** 
	 * 产品主图
	 **/
	public $image_url;
	
	/** 
	 * 产品id
	 **/
	public $product_id;
	
	/** 
	 * 产品描述
	 **/
	public $subject;
	
	/** 
	 * valid
	 **/
	public $valid;	
}
?>