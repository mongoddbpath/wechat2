<?php

/**
 * 更新请求
 * @author auto create
 */
class ProductInventoryRequest
{
	
	/** 
	 * 待更新的库存列表
	 **/
	public $inventory_list;
	
	/** 
	 * 商品id
	 **/
	public $product_id;	
}
?>