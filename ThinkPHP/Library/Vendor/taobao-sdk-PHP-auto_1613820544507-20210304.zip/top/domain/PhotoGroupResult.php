<?php

/**
 * 接口返回的数据结果
 * @author auto create
 */
class PhotoGroupResult
{
	
	/** 
	 * add操作中表示新增的图片分组，rename操作中表示重命名的分组，delete操作中返回分组信息
	 **/
	public $photobank_group;	
}
?>