<?php

/**
 * 阶梯交期
 * @author auto create
 */
class DeliverPeriod
{
	
	/** 
	 * 发货时间
	 **/
	public $process_period;
	
	/** 
	 * 最大订购量
	 **/
	public $quantity;	
}
?>