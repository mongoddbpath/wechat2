<?php

/**
 * 图片查询结果
 * @author auto create
 */
class PaginationQueryList
{
	
	/** 
	 * list
	 **/
	public $list;	
}
?>