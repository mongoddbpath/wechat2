<?php

/**
 * 结果
 * @author auto create
 */
class MtopResultDto
{
	
	/** 
	 * id列表
	 **/
	public $model;
	
	/** 
	 * 返回码
	 **/
	public $msg_code;
	
	/** 
	 * 错误信息
	 **/
	public $msg_info;	
}
?>