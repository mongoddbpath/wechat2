<?php

/**
 * 定制信息
 * @author auto create
 */
class CustomInfo
{
	
	/** 
	 * 定制项
	 **/
	public $custom_contents;	
}
?>