<?php

/**
 * 接口返回对象
 * @author auto create
 */
class ResultDto
{
	
	/** 
	 * 接口返回对象
	 **/
	public $dto;	
}
?>