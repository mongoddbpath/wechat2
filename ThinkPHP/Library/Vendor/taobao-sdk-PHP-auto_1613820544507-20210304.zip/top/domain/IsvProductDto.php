<?php

/**
 * id列表
 * @author auto create
 */
class IsvProductDto
{
	
	/** 
	 * 加密商品id
	 **/
	public $product_id;	
}
?>