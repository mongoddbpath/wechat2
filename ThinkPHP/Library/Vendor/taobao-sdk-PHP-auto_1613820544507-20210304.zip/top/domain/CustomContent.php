<?php

/**
 * 定制项
 * @author auto create
 */
class CustomContent
{
	
	/** 
	 * 定制类型
	 **/
	public $custom_type;
	
	/** 
	 * 定制最小起订量
	 **/
	public $min_order_quantity;	
}
?>